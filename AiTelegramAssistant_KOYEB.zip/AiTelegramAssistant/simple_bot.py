
import os
import asyncio
from pyrogram import Client, filters
from pyrogram.types import Message, InlineKeyboardMarkup, InlineKeyboardButton
from g4f.client import Client as G4FClient
from g4f.Provider import RetryProvider, You, FreeChatgpt
from flask import Flask
import threading
import time

# Set your credentials
BOT_TOKEN = os.getenv("BOT_TOKEN", "7772232548:AAGQg4EOWpU2oujJYLREtOxsf4u1hTCYXEU")
API_ID = int(os.getenv("API_ID", "29970536"))
API_HASH = os.getenv("API_HASH", "f4bfdcdd4a5c1b7328a7e4f25f024a09")

# Create sessions directory
os.makedirs("sessions", exist_ok=True)

# Initialize bot with session in sessions folder
app = Client("simple_bot", bot_token=BOT_TOKEN, api_id=API_ID, api_hash=API_HASH, workdir="./sessions")

# AI setup with RetryProvider
ai_client = G4FClient(provider=RetryProvider([You, FreeChatgpt]))

# Flask for Replit uptime on different port
flask_app = Flask(__name__)

@flask_app.route('/')
def home():
    return """
    <html>
        <head><title>Simple Group Bot</title></head>
        <body style="font-family: Arial, sans-serif; text-align: center; margin-top: 50px;">
            <h1>🤖 Simple Group Bot</h1>
            <p>✅ Bot is running successfully!</p>
            <p>🔗 This bot only works in groups</p>
        </body>
    </html>
    """

@flask_app.route('/status')
def status():
    return {"status": "online", "message": "Group-only bot is running"}

def run_flask():
    try:
        flask_app.run(host="0.0.0.0", port=8000, debug=False)
    except Exception as e:
        print(f"Flask error: {e}")

# Start Flask in background
threading.Thread(target=run_flask, daemon=True).start()

# /start command
@app.on_message(filters.command("start"))
async def start(client, message: Message):
    btn = [[
        InlineKeyboardButton("📢 Channel", url="https://t.me/asbhai_bsr"),
        InlineKeyboardButton("💬 Group", url="https://t.me/aschat_group")
    ]]
    await message.reply_text(
        "👋 **Welcome!**\n\n"
        "🔸 Ye bot sirf group me kaam karta hai\n"
        "🔸 Join karo group aur wahan use karo\n"
        "🔸 Group me message send karo, main reply karunga!",
        reply_markup=InlineKeyboardMarkup(btn)
    )

# Group me AI reply
@app.on_message(filters.group & filters.text & ~filters.command(["start"]))
async def group_ai_reply(client, message: Message):
    try:
        user_msg = message.text
        
        # Skip if message is too short
        if len(user_msg.strip()) < 2:
            return
            
        await client.send_chat_action(message.chat.id, "typing")
        
        # Create AI response
        response = ai_client.chat.completions.create(
            model="gpt-3.5-turbo",
            messages=[{
                "role": "user", 
                "content": f"Reply in a friendly, helpful way (Hindi/English mix is fine): {user_msg}"
            }]
        )
        
        ai_reply = response.choices[0].message.content
        await message.reply_text(ai_reply)
        
    except Exception as e:
        print(f"AI Error: {e}")
        await message.reply_text("⚠️ AI se reply nahi aaya. Thoda baad me try karo!")

# Private message – sirf group-only ka message de
@app.on_message(filters.private & filters.text & ~filters.command("start"))
async def reject_private(client, message: Message):
    await message.reply_text(
        "🚫 **Sorry!**\n\n"
        "Ye bot sirf group me kaam karta hai.\n"
        "Group join karo aur wahan message karo! 😊"
    )

# Test command
@app.on_message(filters.command("test"))
async def test_command(client, message: Message):
    await message.reply_text("✅ Bot working perfectly! 🤖")

async def main():
    print("🤖 Simple Group Bot is starting...")
    
    # Wait a bit to ensure Flask starts
    await asyncio.sleep(2)
    
    async with app:
        # Get bot info
        me = await app.get_me()
        print(f"✅ Bot started: @{me.username}")
        print(f"🔗 Bot Link: https://t.me/{me.username}")
        print(f"🌐 Web Server: Running on port 8000")
        print("💬 Ready for group chats!")
        
        # Keep running
        await asyncio.Event().wait()

if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        print("\n🛑 Bot stopped by user")
    except Exception as e:
        print(f"❌ Error: {e}")
