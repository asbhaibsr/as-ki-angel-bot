"""
Message handlers for AS Ki Angel Telegram Bot
"""
import asyncio
import logging
from pyrogram import filters
from pyrogram.types import Message, InlineKeyboardMarkup, InlineKeyboardButton
from pyrogram.errors import FloodWait, ChatWriteForbidden, UserIsBlocked, PeerIdInvalid

from database import db_manager
from utils import ai_client, is_owner, format_stats_message, format_broadcast_result
from config import (
    WELCOME_MESSAGE, PRIVATE_FORWARD_MESSAGE, ERROR_MESSAGE,
    WELCOME_PHOTO_URL, OWNER_ID, GROUP_USERNAME, CHANNEL_USERNAME
)

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def setup_handlers(bot):
    """Setup all message handlers for the bot"""
    
    @bot.on_message(filters.command("start") & filters.private)
    async def start_command(client, message: Message):
        """Handle /start command in private chats"""
        try:
            # Add user to database
            user_name = message.from_user.first_name or "User"
            db_manager.add_user(message.from_user.id, user_name)
            
            # Send welcome photo
            await message.reply_photo(photo=WELCOME_PHOTO_URL)
            
            # Create welcome message
            text = WELCOME_MESSAGE.format(user_name)
            
            # Create inline keyboard
            buttons = InlineKeyboardMarkup([
                [InlineKeyboardButton(
                    "➕ Add Me to Your Group", 
                    url=f"https://t.me/{client.me.username}?startgroup=true"
                )],
                [InlineKeyboardButton("💬 Chat Group", url=f"https://t.me/{GROUP_USERNAME.replace('@', '')}")],
                [InlineKeyboardButton("📢 Channel", url=f"https://t.me/{CHANNEL_USERNAME.replace('@', '')}")]
            ])
            
            await message.reply(text, reply_markup=buttons)
            logger.info(f"Start command handled for user {message.from_user.id}")
            
        except Exception as e:
            logger.error(f"Error in start command: {e}")
            await message.reply("⚠️ Something went wrong. Please try again later.")

    @bot.on_message(filters.text & ~filters.private & ~filters.command(["stats", "broadcast", "cleardb"]))
    async def group_chat_handler(client, message: Message):
        """Handle group chat messages with AI responses"""
        try:
            # Add group to database
            group_name = message.chat.title or "Unknown Group"
            db_manager.add_group(message.chat.id, group_name)
            
            # Skip if message starts with command
            if message.text.startswith("/"):
                return
            
            # Show typing indicator
            await message.chat.send_chat_action("typing")
            
            # Get AI response
            ai_response = await ai_client.get_ai_response(message.text)
            
            if ai_response:
                await message.reply_text(ai_response)
                logger.info(f"AI response sent in group {message.chat.id}")
            else:
                await message.reply(ERROR_MESSAGE)
                logger.warning(f"Failed to get AI response for group {message.chat.id}")
                
        except FloodWait as e:
            logger.warning(f"FloodWait: sleeping for {e.value} seconds")
            await asyncio.sleep(e.value)
        except Exception as e:
            logger.error(f"Error in group chat handler: {e}")
            try:
                await message.reply(ERROR_MESSAGE)
            except:
                pass

    @bot.on_message(filters.private & filters.text & ~filters.command(["start", "stats", "broadcast", "cleardb"]))
    async def forward_private(client, message: Message):
        """Forward private messages to owner"""
        try:
            # Forward message to owner
            await message.forward(OWNER_ID)
            
            # Send confirmation to user
            await message.reply(PRIVATE_FORWARD_MESSAGE)
            
            logger.info(f"Private message forwarded from user {message.from_user.id}")
            
        except Exception as e:
            logger.error(f"Error forwarding private message: {e}")
            await message.reply("⚠️ Message could not be forwarded. Please contact support.")

    @bot.on_message(filters.command("broadcast") & filters.user(OWNER_ID))
    async def broadcast_handler(client, message: Message):
        """Handle broadcast command (owner only)"""
        try:
            # Check if replying to a message
            if not message.reply_to_message:
                await message.reply("❌ <b>Please reply to a message to broadcast it.</b>")
                return
            
            # Get all users and groups
            users = db_manager.get_all_users()
            groups = db_manager.get_all_groups()
            total_chats = users + groups
            
            if not total_chats:
                await message.reply("❌ <b>No users or groups found in database.</b>")
                return
            
            # Send initial status
            status_message = await message.reply(f"📤 <b>Broadcasting to {len(total_chats)} chats...</b>")
            
            success_count = 0
            
            # Broadcast to all chats
            for chat_data in total_chats:
                try:
                    await message.reply_to_message.copy(chat_data["_id"])
                    success_count += 1
                    
                    # Update status every 10 successful sends
                    if success_count % 10 == 0:
                        await status_message.edit_text(
                            f"📤 <b>Broadcasting...</b>\n✅ Sent: {success_count}/{len(total_chats)}"
                        )
                    
                    # Small delay to avoid flood limits
                    await asyncio.sleep(0.1)
                    
                except FloodWait as e:
                    logger.warning(f"FloodWait during broadcast: {e.value} seconds")
                    await asyncio.sleep(e.value)
                except (ChatWriteForbidden, UserIsBlocked, PeerIdInvalid):
                    # These are expected errors for blocked/deleted users
                    continue
                except Exception as e:
                    logger.error(f"Broadcast error for chat {chat_data['_id']}: {e}")
                    continue
            
            # Send final result
            result_message = format_broadcast_result(success_count, len(total_chats))
            await status_message.edit_text(result_message)
            
            logger.info(f"Broadcast completed: {success_count}/{len(total_chats)} successful")
            
        except Exception as e:
            logger.error(f"Error in broadcast handler: {e}")
            await message.reply("❌ <b>Broadcast failed. Please try again.</b>")

    @bot.on_message(filters.command("stats") & filters.user(OWNER_ID))
    async def stats_handler(client, message: Message):
        """Handle stats command (owner only)"""
        try:
            users_count = db_manager.get_users_count()
            groups_count = db_manager.get_groups_count()
            
            stats_message = format_stats_message(users_count, groups_count)
            await message.reply_text(stats_message)
            
            logger.info(f"Stats requested: {users_count} users, {groups_count} groups")
            
        except Exception as e:
            logger.error(f"Error in stats handler: {e}")
            await message.reply("❌ <b>Failed to fetch statistics.</b>")

    @bot.on_message(filters.command("cleardb") & filters.user(OWNER_ID))
    async def clear_db_handler(client, message: Message):
        """Handle database clearing command (owner only)"""
        try:
            # Send confirmation message
            confirm_message = await message.reply(
                "⚠️ <b>Are you sure you want to delete ALL data?</b>\n\n"
                "This action cannot be undone!\n\n"
                "Reply with 'CONFIRM DELETE' to proceed."
            )
            
            # Wait for confirmation (simple implementation)
            # In a production bot, you might want to use inline keyboards for confirmation
            await message.reply(
                "🛑 <b>Database clearing requires manual confirmation.</b>\n\n"
                "To clear the database, use the MongoDB interface directly for safety."
            )
            
            logger.info(f"Database clear requested by owner {message.from_user.id}")
            
        except Exception as e:
            logger.error(f"Error in clear_db handler: {e}")
            await message.reply("❌ <b>Failed to process clear database command.</b>")

    @bot.on_message(filters.command("help") & filters.user(OWNER_ID))
    async def help_handler(client, message: Message):
        """Handle help command (owner only)"""
        help_text = """🤖 <b>AS Ki Angel Bot - Admin Commands</b>

<b>Available Commands:</b>
• /stats - Get bot statistics
• /broadcast - Broadcast a message (reply to message)
• /cleardb - Clear database (with confirmation)
• /help - Show this help message

<b>Bot Features:</b>
• 💬 AI chat in groups
• 📤 Private message forwarding
• 📊 User/Group tracking
• 🔄 Auto-database updates

<b>Status:</b> ✅ Running
<b>AI:</b> ✅ Active
<b>Database:</b> ✅ Connected"""

        await message.reply_text(help_text)

    logger.info("All handlers setup completed")
