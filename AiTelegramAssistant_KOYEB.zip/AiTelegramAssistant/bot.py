# ✅ AS KI ANGEL 😇 TELEGRAM AI BOT CODE
# Final working version with group chat reply, AI, MongoDB, broadcast, private message forward, always-on Replit

import os
from pyrogram import Client, filters
from pyrogram.types import Message, InlineKeyboardMarkup, InlineKeyboardButton
from pymongo import MongoClient
import asyncio
from g4f.client import Client as G4FClient
from g4f.Provider import RetryProvider
from flask import Flask
from threading import Thread

# === BOT CONFIGURATION ===
API_ID = 29970536
API_HASH = "f4bfdcdd4a5c1b7328a7e4f25f024a09"
BOT_TOKEN = os.getenv("BOT_TOKEN", "7772232548:AAGQg4EOWpU2oujJYLREtOxsf4u1hTCYXEU")
OWNER_ID = 7315805581
GROUP_USERNAME = "@aschat_group"
CHANNEL_USERNAME = "@asbhai_bsr"

# === DATABASE ===
MONGO_URL = "mongodb+srv://mogode3996:D96XSFbqWQ9thyP3@cluster0.6kmff.mongodb.net/?retryWrites=true&w=majority"

# Initialize MongoDB with error handling
try:
    mongo_client = MongoClient(MONGO_URL, serverSelectionTimeoutMS=5000)
    # Test connection
    mongo_client.admin.command('ping')
    db = mongo_client.bot_users
    groups_col = db.groups
    users_col = db.users
    print("✅ MongoDB connected successfully")
except Exception as e:
    print(f"⚠️ MongoDB connection failed: {e}")
    print("Bot will run without database features")
    mongo_client = None
    db = None
    groups_col = None
    users_col = None

# === INITIATE BOT ===
bot = Client("as_ki_angel", api_id=API_ID, api_hash=API_HASH, bot_token=BOT_TOKEN)

# G4F AI Setup
from g4f.Provider import You
ai_client = G4FClient(provider=RetryProvider([You]))

# === START COMMAND ===
@bot.on_message(filters.command("start") & filters.private)
async def start_command(client, message: Message):
    # Save user to database if available
    if users_col is not None:
        try:
            users_col.update_one({"_id": message.from_user.id}, {"$set": {"name": message.from_user.first_name}}, upsert=True)
        except Exception as e:
            print(f"Database error: {e}")

    me = await client.get_me()
    await message.reply_photo(
        photo="https://envs.sh/X2Z.jpg",
        caption=(
            f"<b>💖 Heyyyyy {message.from_user.first_name}!!\n\n"
            "Main hoon <i>AS Ki Angel 😇</i> — ek cute si, dil se baat karne wali AI girl. "
            "Tumhare dard, khushi, ya boredom sab kuch sunne ke liye yahan hoon...\n\n"
            "💬 Mujhse baat karne ka maza hi kuch aur hai!\n\n"
            "🔗 Mujhe apne group me add karo ya hamara channel join karo!\n</b>"
        ),
        reply_markup=InlineKeyboardMarkup([
            [InlineKeyboardButton("➕ Add Me to Your Group", url=f"https://t.me/{me.username}?startgroup=true")],
            [InlineKeyboardButton("💬 Chat Group", url="https://t.me/aschat_group")],
            [InlineKeyboardButton("📢 Channel", url="https://t.me/asbhai_bsr")]
        ])
    )

# === GROUP CHAT HANDLER ===
@bot.on_message(filters.group & filters.text & ~filters.command(["start", "broadcast", "stats", "cleardb"]))
async def group_chat_handler(client, message: Message):
    # Save group to database if available
    if groups_col is not None:
        try:
            groups_col.update_one({"_id": message.chat.id}, {"$set": {"name": message.chat.title}}, upsert=True)
        except Exception as e:
            print(f"Database error: {e}")
    try:
        await client.send_chat_action(message.chat.id, "typing")

        # Add personality context for better responses
        context_message = f"""You are AS Ki Angel 😇, a cute, friendly AI girl who loves to chat with people in Hindi and English. 
        You're caring, empathetic, and always ready to listen to people's problems, happiness, or boredom sab kuch sunne ke liye yahan hoon...

        User message: {message.text}"""

        response = ai_client.chat.completions.create(
            model="gpt-3.5-turbo",
            messages=[{"role": "user", "content": context_message}]
        )
        await message.reply_text(response.choices[0].message.content)
    except Exception as e:
        print(f"AI Error: {e}")
        await message.reply("⚠️ Bot thoda busy hai. Baad mein try karein.")

# === PRIVATE MESSAGE HANDLER ===
@bot.on_message(filters.private & filters.text & ~filters.command(["start", "broadcast", "stats", "cleardb"]))
async def private_forward(client, message: Message):
    try:
        await message.forward(OWNER_ID)
        await message.reply("✅ Message owner tak bhej diya gaya hai!\n\nItne main aap hamare group pr jake chat kar sakte hai 😊\n👉 @aschat_group")
    except Exception as e:
        print(f"Forward Error: {e}")
        await message.reply("⚠️ Message could not be forwarded.")

# === BROADCAST TO USERS & GROUPS ===
@bot.on_message(filters.user(OWNER_ID) & filters.command("broadcast"))
async def broadcast_handler(client, message: Message):
    if not message.reply_to_message:
        return await message.reply("Reply to a message to broadcast.")

    if groups_col is None or users_col is None:
        return await message.reply("❌ Database not connected")

    count = 0
    try:
        for col in [groups_col, users_col]:
            for doc in col.find():
                try:
                    await message.reply_to_message.copy(doc["_id"])
                    count += 1
                    await asyncio.sleep(0.1)  # Avoid flood limits
                except:
                    continue
        await message.reply(f"✅ Broadcast sent to {count} chats.")
    except Exception as e:
        await message.reply(f"❌ Broadcast failed: {e}")

# === STATS ===
@bot.on_message(filters.command("stats") & filters.user(OWNER_ID))
async def stats(client, message):
    if users_col is not None and groups_col is not None:
        try:
            users = users_col.count_documents({})
            groups = groups_col.count_documents({})
            await message.reply_text(f"📊 Stats:\n👤 Users: {users}\n👥 Groups: {groups}\n🎯 Total: {users + groups}")
        except Exception as e:
            await message.reply(f"❌ Database error: {e}")
    else:
        await message.reply("❌ Database not connected")

# === DELETE ALL MONGO DATA ===
@bot.on_message(filters.command("cleardb") & filters.user(OWNER_ID))
async def clear_db(client, message):
    if users_col is not None and groups_col is not None:
        try:
            users_col.delete_many({})
            groups_col.delete_many({})
            await message.reply("🗑️ All data deleted from MongoDB.")
        except Exception as e:
            await message.reply(f"❌ Failed to clear database: {e}")
    else:
        await message.reply("❌ Database not connected")

# === TEST COMMAND ===
@bot.on_message(filters.command("test"))
async def test_command(client, message: Message):
    await message.reply("✅ Haan main yahan hoon! Bot working perfectly! 💖")

# === KEEP ALIVE FOR REPLIT ===
app = Flask('')

@app.route('/')
def home():
    return """
    <html>
        <head><title>AS Ki Angel Bot</title></head>
        <body style="font-family: Arial, sans-serif; text-align: center; margin-top: 50px;">
            <h1>🤖 AS Ki Angel Bot</h1>
            <p>✅ Bot is running successfully!</p>
            <p>💖 Ready to chat with users</p>
            <hr>
            <small>Keep-alive server active</small>
        </body>
    </html>
    """

@app.route('/health')
def health():
    users = users_col.count_documents({})
    groups = groups_col.count_documents({})
    return {"status": "healthy", "users": users, "groups": groups}

def run():
    app.run(host='0.0.0.0', port=5000)

def main():
    # Start Flask server in background
    Thread(target=run, daemon=True).start()
    print("✅ Flask server started on port 5000")

    # Run bot
    print("🤖 AS KI ANGEL BOT IS RUNNING...")
    bot.run()

if __name__ == "__main__":
    main()