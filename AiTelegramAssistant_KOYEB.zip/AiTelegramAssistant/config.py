"""
Configuration settings for AS Ki Angel Telegram Bot
"""
import os

# Bot Configuration
API_ID = int(os.getenv("API_ID", "29970536"))
API_HASH = os.getenv("API_HASH", "f4bfdcdd4a5c1b7328a7e4f25f024a09")
BOT_TOKEN = os.getenv("BOT_TOKEN", "7772232548:AAGQg4EOWpU2oujJYLREtOxsf4u1hTCYXEU")
OWNER_ID = int(os.getenv("OWNER_ID", "7315805581"))

# Channel and Group Configuration
GROUP_USERNAME = os.getenv("GROUP_USERNAME", "@aschat_group")
CHANNEL_USERNAME = os.getenv("CHANNEL_USERNAME", "@asbhai_bsr")

# Database Configuration
MONGO_URL = os.getenv("MONGO_URL", "mongodb+srv://mogode3996:D96XSFbqWQ9thyP3@cluster0.6kmff.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0")

# Welcome Photo URL
WELCOME_PHOTO_URL = os.getenv("WELCOME_PHOTO_URL", "https://envs.sh/X2Z.jpg")

# Flask Configuration
FLASK_HOST = "0.0.0.0"
FLASK_PORT = 5000

# Bot Messages
WELCOME_MESSAGE = """<b>💖 Heyyyyy {}!!

Main hoon <i>AS Ki Angel 😇</i> — ek cute si, dil se baat karne wali AI girl. 
Tumhare dard, khushi, ya boredom sab kuch sunne ke liye yahan hoon...

💬 Mujhse baat karne ka maza hi kuch aur hai!

🔗 Mujhe apne group me add karo ya hamara channel join karo!</b>"""

PRIVATE_FORWARD_MESSAGE = """✅ Message owner tak bhej diya gaya hai!

Itne main aap hamare group pr jake chat kar sakte hai 😊
👉 @aschat_group"""

ERROR_MESSAGE = "⚠️ Kuch galti ho gayi! Try again later."
