# ✅ AS KI ANGEL 😇 TELEGRAM AI BOT CODE
# Made for Replit - Includes: Welcome photo, group-only chat, private message forward, broadcast, PostgreSQL stats, and free AI chat (g4f)

import os
import asyncio
import psycopg2
from pyrogram import Client, filters
from pyrogram.types import Message, InlineKeyboardMarkup, InlineKeyboardButton
from g4f.client import Client as G4FClient
from flask import Flask
from threading import Thread

# === BOT CONFIGURATION ===
API_ID = 29970536
API_HASH = "f4bfdcdd4a5c1b7328a7e4f25f024a09"
BOT_TOKEN = os.getenv("BOT_TOKEN", "YOUR_BOT_TOKEN_HERE")
OWNER_ID = 7315805581
GROUP_USERNAME = "@aschat_group"
CHANNEL_USERNAME = "@asbhai_bsr"

# === DATABASE SETUP ===
DATABASE_URL = os.getenv("DATABASE_URL")

def init_database():
    """Initialize PostgreSQL database tables"""
    try:
        if not DATABASE_URL:
            print("❌ DATABASE_URL not found")
            return False
            
        conn = psycopg2.connect(DATABASE_URL)
        cursor = conn.cursor()
        
        # Create users table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS users (
                user_id BIGINT PRIMARY KEY,
                name VARCHAR(255),
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        
        # Create groups table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS groups (
                group_id BIGINT PRIMARY KEY,
                name VARCHAR(255),
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        
        conn.commit()
        cursor.close()
        conn.close()
        print("✅ Database initialized successfully")
        return True
    except Exception as e:
        print(f"❌ Database initialization failed: {e}")
        return False

def add_user(user_id: int, name: str):
    """Add user to database"""
    try:
        conn = psycopg2.connect(DATABASE_URL)
        cursor = conn.cursor()
        cursor.execute(
            "INSERT INTO users (user_id, name) VALUES (%s, %s) ON CONFLICT (user_id) DO UPDATE SET name = %s",
            (user_id, name, name)
        )
        conn.commit()
        cursor.close()
        conn.close()
    except Exception as e:
        print(f"Error adding user: {e}")

def add_group(group_id: int, name: str):
    """Add group to database"""
    try:
        conn = psycopg2.connect(DATABASE_URL)
        cursor = conn.cursor()
        cursor.execute(
            "INSERT INTO groups (group_id, name) VALUES (%s, %s) ON CONFLICT (group_id) DO UPDATE SET name = %s",
            (group_id, name, name)
        )
        conn.commit()
        cursor.close()
        conn.close()
    except Exception as e:
        print(f"Error adding group: {e}")

def get_stats():
    """Get user and group counts"""
    try:
        conn = psycopg2.connect(DATABASE_URL)
        cursor = conn.cursor()
        
        cursor.execute("SELECT COUNT(*) FROM users")
        result = cursor.fetchone()
        users_count = result[0] if result else 0
        
        cursor.execute("SELECT COUNT(*) FROM groups")
        result = cursor.fetchone()
        groups_count = result[0] if result else 0
        
        cursor.close()
        conn.close()
        return users_count, groups_count
    except Exception as e:
        print(f"Error getting stats: {e}")
        return 0, 0

def get_all_chats():
    """Get all user and group IDs for broadcasting"""
    try:
        conn = psycopg2.connect(DATABASE_URL)
        cursor = conn.cursor()
        
        cursor.execute("SELECT user_id FROM users")
        users = [row[0] for row in cursor.fetchall()]
        
        cursor.execute("SELECT group_id FROM groups")
        groups = [row[0] for row in cursor.fetchall()]
        
        cursor.close()
        conn.close()
        return users + groups
    except Exception as e:
        print(f"Error getting chats: {e}")
        return []

def clear_database():
    """Clear all data from database"""
    try:
        conn = psycopg2.connect(DATABASE_URL)
        cursor = conn.cursor()
        cursor.execute("DELETE FROM users")
        cursor.execute("DELETE FROM groups")
        conn.commit()
        cursor.close()
        conn.close()
        return True
    except Exception as e:
        print(f"Error clearing database: {e}")
        return False

# === INITIATE BOT ===
bot = Client("as_ki_angel_bot", api_id=API_ID, api_hash=API_HASH, bot_token=BOT_TOKEN)
ai_client = G4FClient()

# === START COMMAND ===
@bot.on_message(filters.command("start") & filters.private)
async def start_command(client, message: Message):
    user_name = message.from_user.first_name or "User"
    add_user(message.from_user.id, user_name)
    
    await message.reply_photo(photo="https://envs.sh/X2Z.jpg")
    text = (
        f"<b>💖 Heyyyyy {user_name}!!\n\n"
        "Main hoon <i>AS Ki Angel 😇</i> — ek cute si, dil se baat karne wali AI girl. "
        "Tumhare dard, khushi, ya boredom sab kuch sunne ke liye yahan hoon...\n\n"
        "💬 Mujhse baat karne ka maza hi kuch aur hai!\n\n"
        "🔗 Mujhe apne group me add karo ya hamara channel join karo!\n</b>"
    )
    buttons = InlineKeyboardMarkup([
        [InlineKeyboardButton("➕ Add Me to Your Group", url=f"https://t.me/{client.me.username}?startgroup=true")],
        [InlineKeyboardButton("💬 Chat Group", url="https://t.me/aschat_group")],
        [InlineKeyboardButton("📢 Channel", url="https://t.me/asbhai_bsr")]
    ])
    await message.reply(text, reply_markup=buttons)

# === GROUP ONLY CHAT ===
@bot.on_message(filters.text & ~filters.private & ~filters.command(["stats", "broadcast", "cleardb"]))
async def group_chat_handler(client, message: Message):
    group_name = message.chat.title or "Unknown Group"
    add_group(message.chat.id, group_name)
    
    if message.text.startswith("/"):
        return
    
    await client.send_chat_action(message.chat.id, "typing")
    try:
        # Add personality context for better responses
        context_message = f"""You are AS Ki Angel 😇, a cute, friendly AI girl who loves to chat with people in Hindi and English. 
        You're caring, empathetic, and always ready to listen to people's problems, happiness, or just casual chat.
        Keep responses conversational, warm, and helpful. Use a mix of Hindi and English naturally.
        
        User message: {message.text}"""
        
        reply = ai_client.chat.completions.create(
            model="gpt-3.5-turbo",
            messages=[{"role": "user", "content": context_message}]
        )
        await message.reply_text(reply.choices[0].message.content)
    except Exception as e:
        print(f"AI Error: {e}")
        await message.reply("⚠️ Kuch galti ho gayi! Try again later.")

# === PRIVATE MESSAGE FORWARDING ===
@bot.on_message(filters.private & filters.text & ~filters.command(["start", "stats", "broadcast", "cleardb"]))
async def forward_private(client, message: Message):
    try:
        await message.forward(OWNER_ID)
        await message.reply("✅ Message owner tak bhej diya gaya hai!\n\nItne main aap hamare group pr jake chat kar sakte hai 😊\n👉 @aschat_group")
    except Exception as e:
        print(f"Forward error: {e}")
        await message.reply("⚠️ Message could not be forwarded.")

# === BROADCAST COMMAND ===
@bot.on_message(filters.user(OWNER_ID) & filters.command("broadcast"))
async def broadcast_handler(client, message: Message):
    if not message.reply_to_message:
        return await message.reply("❌ Reply to a message to broadcast it.")
    
    chats = get_all_chats()
    if not chats:
        return await message.reply("❌ No chats found in database.")
    
    status_msg = await message.reply(f"📤 Broadcasting to {len(chats)} chats...")
    success_count = 0
    
    for chat_id in chats:
        try:
            await message.reply_to_message.copy(chat_id)
            success_count += 1
            await asyncio.sleep(0.1)  # Avoid flood limits
        except Exception as e:
            print(f"Broadcast error for {chat_id}: {e}")
            continue
    
    await status_msg.edit_text(f"✅ Broadcast completed!\n📤 Sent to {success_count}/{len(chats)} chats")

# === STATS COMMAND ===
@bot.on_message(filters.command("stats") & filters.user(OWNER_ID))
async def stats_handler(client, message):
    users_count, groups_count = get_stats()
    stats_text = f"""📊 <b>Bot Statistics</b>

👤 <b>Users:</b> {users_count}
👥 <b>Groups:</b> {groups_count}
🎯 <b>Total Chats:</b> {users_count + groups_count}

💖 AS Ki Angel Bot is running smoothly!"""
    await message.reply_text(stats_text)

# === DELETE ALL DATA ===
@bot.on_message(filters.command("cleardb") & filters.user(OWNER_ID))
async def clear_db(client, message):
    if clear_database():
        await message.reply("🗑️ All data deleted from database.")
    else:
        await message.reply("❌ Failed to clear database.")

# === HELP COMMAND ===
@bot.on_message(filters.command("help") & filters.user(OWNER_ID))
async def help_handler(client, message):
    help_text = """🤖 <b>AS Ki Angel Bot - Admin Commands</b>

<b>Available Commands:</b>
• /stats - Get bot statistics
• /broadcast - Broadcast a message (reply to message)
• /cleardb - Clear database
• /help - Show this help message

<b>Bot Features:</b>
• 💬 AI chat in groups
• 📤 Private message forwarding
• 📊 PostgreSQL database tracking
• 🔄 Automatic user/group updates

<b>Status:</b> ✅ Running
<b>AI:</b> ✅ Active (G4F)
<b>Database:</b> ✅ PostgreSQL Connected"""

    await message.reply_text(help_text)

# === KEEP ALIVE SERVER ===
app = Flask(__name__)

@app.route('/')
def home():
    return """
    <html>
        <head><title>AS Ki Angel Bot</title></head>
        <body style="font-family: Arial, sans-serif; text-align: center; margin-top: 50px;">
            <h1>🤖 AS Ki Angel Bot</h1>
            <p>✅ Bot is running successfully!</p>
            <p>💖 Ready to chat with users</p>
            <hr>
            <small>Keep-alive server active on port 5000</small>
        </body>
    </html>
    """

@app.route('/stats')
def web_stats():
    users_count, groups_count = get_stats()
    return {
        "users": users_count,
        "groups": groups_count,
        "total_chats": users_count + groups_count,
        "status": "running"
    }

@app.route('/bot-info')
def bot_info():
    try:
        # Get bot username from the running bot instance
        me = asyncio.run(bot.get_me())
        return {
            "username": me.username,
            "first_name": me.first_name,
            "bot_link": f"https://t.me/{me.username}",
            "status": "active"
        }
    except Exception as e:
        return {"error": str(e), "status": "inactive"}

def run_flask():
    app.run(host='0.0.0.0', port=5000, debug=False)

# === MAIN EXECUTION ===
if __name__ == "__main__":
    print("🤖 AS KI ANGEL BOT STARTING...")
    
    # Check bot token
    if BOT_TOKEN == "YOUR_BOT_TOKEN_HERE":
        print("❌ Please set BOT_TOKEN environment variable")
        exit(1)
    
    # Initialize database
    if not init_database():
        print("❌ Database initialization failed")
        exit(1)
    
    # Start Flask server in background
    flask_thread = Thread(target=run_flask, daemon=True)
    flask_thread.start()
    print("✅ Flask server started on port 5000")
    
    # Run bot
    print("🚀 Starting Telegram bot...")
    bot.run()