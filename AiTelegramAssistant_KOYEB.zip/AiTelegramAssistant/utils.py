"""
Utility functions for AS Ki Angel Telegram Bot
"""
import asyncio
import logging
from g4f.client import Client as G4FClient
from g4f.Provider import RetryProvider
from typing import Optional

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class AIClient:
    def __init__(self):
        """Initialize G4F AI client"""
        try:
            self.client = G4FClient(provider=RetryProvider())
            logger.info("AI client initialized successfully")
        except Exception as e:
            logger.error(f"Failed to initialize AI client: {e}")
            self.client = None

    async def get_ai_response(self, message: str) -> Optional[str]:
        """Get AI response for given message"""
        if not self.client:
            logger.error("AI client not initialized")
            return None
        
        try:
            # Add context to make responses more engaging
            context_message = f"""You are AS Ki Angel 😇, a cute, friendly AI girl who loves to chat with people in Hindi and English. 
            You're caring, empathetic, and always ready to listen to people's problems, happiness, or just casual chat.
            Keep responses conversational, warm, and helpful. Use a mix of Hindi and English naturally.
            
            User message: {message}"""
            
            response = await asyncio.to_thread(
                self.client.chat.completions.create,
                model="gpt-3.5-turbo",
                messages=[{"role": "user", "content": context_message}]
            )
            
            if response and response.choices:
                ai_response = response.choices[0].message.content
                logger.info(f"AI response generated successfully")
                return ai_response
            else:
                logger.warning("Empty response from AI")
                return None
                
        except Exception as e:
            logger.error(f"Error getting AI response: {e}")
            return None

# Initialize AI client
ai_client = AIClient()

def is_owner(user_id: int) -> bool:
    """Check if user is the bot owner"""
    from config import OWNER_ID
    return user_id == OWNER_ID

def format_stats_message(users_count: int, groups_count: int) -> str:
    """Format statistics message"""
    return f"""📊 <b>Bot Statistics</b>

👤 <b>Total Users:</b> {users_count}
👥 <b>Total Groups:</b> {groups_count}
🎯 <b>Total Chats:</b> {users_count + groups_count}

💖 Thanks for using AS Ki Angel Bot!"""

def format_broadcast_result(success_count: int, total_count: int) -> str:
    """Format broadcast result message"""
    return f"""✅ <b>Broadcast Complete!</b>

📤 <b>Successfully sent to:</b> {success_count}/{total_count} chats
📊 <b>Success rate:</b> {(success_count/total_count*100):.1f}% 

{'🎉 All messages delivered!' if success_count == total_count else '⚠️ Some messages failed to deliver.'}"""
