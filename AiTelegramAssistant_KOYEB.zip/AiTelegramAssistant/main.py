"""
AS Ki Angel - Telegram AI Bot
A friendly AI chatbot with group management, MongoDB integration, and admin features.
"""
import os
import sys
import asyncio
import logging
from threading import Thread
from flask import Flask
from pyrogram import Client

from config import (
    API_ID, API_HASH, BOT_TOKEN, FLASK_HOST, FLASK_PORT,
    OWNER_ID
)
from handlers import setup_handlers
from database import db_manager

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

class ASKiAngelBot:
    def __init__(self):
        """Initialize the AS Ki Angel Bot"""
        self.bot = None
        self.flask_app = None
        self.setup_flask_server()
        
    def setup_flask_server(self):
        """Setup Flask keep-alive server"""
        self.flask_app = Flask(__name__)
        
        @self.flask_app.route('/')
        def home():
            return """
            <html>
                <head><title>AS Ki Angel Bot</title></head>
                <body style="font-family: Arial, sans-serif; text-align: center; margin-top: 50px;">
                    <h1>🤖 AS Ki Angel Bot</h1>
                    <p>✅ Bot is running successfully!</p>
                    <p>💖 Ready to chat with users</p>
                    <hr>
                    <small>Keep-alive server active</small>
                </body>
            </html>
            """
        
        @self.flask_app.route('/health')
        def health():
            """Health check endpoint"""
            try:
                # Check database connection
                users_count = db_manager.get_users_count()
                groups_count = db_manager.get_groups_count()
                
                return {
                    "status": "healthy",
                    "bot_running": self.bot is not None,
                    "database_connected": True,
                    "users_count": users_count,
                    "groups_count": groups_count
                }
            except Exception as e:
                logger.error(f"Health check failed: {e}")
                return {"status": "unhealthy", "error": str(e)}, 500
        
        @self.flask_app.route('/stats')
        def stats():
            """Public stats endpoint"""
            try:
                users_count = db_manager.get_users_count()
                groups_count = db_manager.get_groups_count()
                
                return {
                    "users": users_count,
                    "groups": groups_count,
                    "total_chats": users_count + groups_count
                }
            except Exception as e:
                return {"error": str(e)}, 500

    def run_flask_server(self):
        """Start Flask server in a separate thread"""
        try:
            self.flask_app.run(host=FLASK_HOST, port=FLASK_PORT, debug=False)
        except Exception as e:
            logger.error(f"Flask server error: {e}")

    def initialize_bot(self):
        """Initialize Pyrogram bot client"""
        try:
            # Validate configuration
            if BOT_TOKEN == "YOUR_BOT_TOKEN_HERE":
                raise ValueError("Please set a valid BOT_TOKEN in environment variables")
            
            # Create bot client
            self.bot = Client(
                "as_ki_angel",
                api_id=API_ID,
                api_hash=API_HASH,
                bot_token=BOT_TOKEN,
                workdir="./sessions"  # Store session files in sessions directory
            )
            
            # Setup message handlers
            setup_handlers(self.bot)
            
            logger.info("Bot initialized successfully")
            return True
            
        except Exception as e:
            logger.error(f"Failed to initialize bot: {e}")
            return False

    async def start_bot(self):
        """Start the bot"""
        try:
            await self.bot.start()
            
            # Get bot info
            me = await self.bot.get_me()
            logger.info(f"Bot started successfully: @{me.username}")
            logger.info(f"Bot ID: {me.id}")
            logger.info(f"Owner ID: {OWNER_ID}")
            
            # Send startup notification to owner
            try:
                await self.bot.send_message(
                    OWNER_ID,
                    "🚀 <b>AS Ki Angel Bot Started!</b>\n\n"
                    f"🤖 <b>Bot:</b> @{me.username}\n"
                    f"🆔 <b>Bot ID:</b> {me.id}\n"
                    f"📊 <b>Database:</b> ✅ Connected\n"
                    f"🔥 <b>AI:</b> ✅ Ready\n\n"
                    "💖 Bot is ready to serve users!"
                )
            except Exception as e:
                logger.warning(f"Could not send startup notification: {e}")
            
            # Keep the bot running
            await asyncio.Event().wait()
            
        except Exception as e:
            logger.error(f"Error starting bot: {e}")
            raise

    def stop_bot(self):
        """Stop the bot gracefully"""
        try:
            if self.bot:
                logger.info("Stopping bot...")
                # The bot will be stopped by the context manager
            
            # Close database connection
            db_manager.close_connection()
            logger.info("Bot stopped successfully")
            
        except Exception as e:
            logger.error(f"Error stopping bot: {e}")

    def run(self):
        """Main entry point to run the bot"""
        try:
            # Start Flask server in background
            flask_thread = Thread(target=self.run_flask_server, daemon=True)
            flask_thread.start()
            logger.info(f"Flask server started on {FLASK_HOST}:{FLASK_PORT}")
            
            # Initialize bot
            if not self.initialize_bot():
                logger.error("Failed to initialize bot. Exiting.")
                return
            
            # Run bot
            logger.info("🤖 AS KI ANGEL BOT STARTING...")
            
            # Create sessions directory
            os.makedirs("sessions", exist_ok=True)
            
            # Start bot with proper error handling
            with self.bot:
                asyncio.get_event_loop().run_until_complete(self.start_bot())
                
        except KeyboardInterrupt:
            logger.info("Bot stopped by user")
        except Exception as e:
            logger.error(f"Critical error: {e}")
        finally:
            self.stop_bot()

def main():
    """Main function"""
    # Check environment
    logger.info("Starting AS Ki Angel Bot...")
    logger.info(f"Python version: {sys.version}")
    logger.info(f"Working directory: {os.getcwd()}")
    
    # Validate critical environment variables
    required_vars = ["BOT_TOKEN"]
    missing_vars = [var for var in required_vars if not os.getenv(var) or os.getenv(var) == "YOUR_BOT_TOKEN_HERE"]
    
    if missing_vars:
        logger.error(f"Missing required environment variables: {missing_vars}")
        logger.info("Please set the following environment variables:")
        for var in missing_vars:
            logger.info(f"  export {var}=your_value_here")
        return
    
    # Create and run bot
    bot_instance = ASKiAngelBot()
    bot_instance.run()

if __name__ == "__main__":
    main()
