# AS Ki Angel Telegram Bot

## Overview

AS Ki Angel is a Telegram AI chatbot that acts as a friendly, empathetic AI assistant. The bot combines AI conversation capabilities with group management features, user database tracking, and administrative functions. It's designed to be a "cute AI girl" that can chat with users in both Hindi and English, providing emotional support and engaging conversations.

## System Architecture

The application follows a modular Python architecture with the following key components:

- **Bot Framework**: Built using Pyrogram for Telegram API interactions
- **AI Integration**: Uses G4F (GPT4Free) for AI conversation capabilities
- **Database**: MongoDB for user and group data persistence
- **Web Server**: Flask for keep-alive functionality and health checks
- **Configuration Management**: Environment-based configuration system

## Key Components

### 1. Bot Core (`main.py`)
- **Purpose**: Main application entry point and bot initialization
- **Architecture Decision**: Uses a class-based approach (`ASKiAngelBot`) for better organization
- **Threading**: Implements Flask server in separate thread for concurrent operation
- **Rationale**: Separates concerns between bot operations and web server functionality

### 2. Message Handlers (`handlers.py`)
- **Purpose**: Processes incoming Telegram messages and commands
- **Key Features**: 
  - `/start` command with welcome flow
  - Private message forwarding to owner
  - Group chat AI responses
  - Admin broadcast functionality
- **Architecture Decision**: Function-based handlers registered with decorators
- **Rationale**: Provides clear separation of different message types and easy extensibility

### 3. Database Layer (`database.py`)
- **Purpose**: MongoDB operations for user and group management
- **Architecture Decision**: Class-based database manager with connection pooling
- **Collections**: 
  - `users`: User ID, name tracking
  - `groups`: Group ID, name tracking
- **Error Handling**: Comprehensive logging and exception handling for database operations

### 4. AI Integration (`utils.py`)
- **Purpose**: AI conversation capabilities using G4F
- **Architecture Decision**: Separate AI client class with context injection
- **Context Strategy**: Injects personality context to maintain consistent AI character
- **Language Support**: Designed for Hindi-English mixed conversations

### 5. Configuration (`config.py`)
- **Purpose**: Centralized configuration management
- **Environment Variables**: API credentials, database URLs, bot settings
- **Default Values**: Fallback values for development/testing
- **Message Templates**: Predefined responses and welcome messages

## Data Flow

1. **User Interaction**: User sends message to bot via Telegram
2. **Message Processing**: Pyrogram receives and routes message to appropriate handler
3. **Database Update**: User/group information stored/updated in MongoDB
4. **AI Processing**: For chat messages, G4F generates contextual AI responses
5. **Response Delivery**: Bot sends response back through Telegram API

## External Dependencies

### Required Services
- **Telegram Bot API**: Core bot functionality
- **MongoDB Atlas**: User and group data storage
- **G4F/OpenAI**: AI conversation capabilities

### Python Packages
- `pyrogram`: Telegram bot framework
- `pymongo`: MongoDB driver
- `g4f`: AI/GPT integration
- `flask`: Web server for keep-alive
- `tgcrypto`: Telegram encryption support

## Deployment Strategy

### Replit Deployment
- **Environment**: Python 3.11 with Nix package management
- **Process Management**: Parallel workflow execution
- **Port Configuration**: Flask server on port 5000
- **Keep-Alive**: Flask server prevents Replit from sleeping

### Configuration Requirements
- Set environment variables for API credentials
- MongoDB connection string
- Telegram bot token and API credentials
- Owner ID for admin functions

### Scaling Considerations
- MongoDB provides horizontal scaling capability
- G4F offers fallback AI providers for reliability
- Stateless design allows for easy horizontal scaling

## Changelog

```
Changelog:
- June 15, 2025: Initial setup with modular architecture
- June 15, 2025: Converted to single-file implementation using PostgreSQL
- June 15, 2025: Fixed session conflicts and deployed working bot @asbhai1_bot
- June 15, 2025: Bot fully operational with group chat AI responses
```

## User Preferences

```
Preferred communication style: Simple, everyday language.
```

## Notes for Development

- The bot uses a hybrid personality (Hindi-English AI assistant)
- Database operations include proper error handling and logging
- Flask server serves as both health check and keep-alive mechanism
- All sensitive configuration stored in environment variables
- Modular design allows for easy feature additions and modifications