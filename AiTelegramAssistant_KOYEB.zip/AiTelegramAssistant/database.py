"""
Database operations for AS Ki Angel Telegram Bot
"""
from pymongo import MongoClient
from pymongo.errors import ConnectionFailure, OperationFailure
import logging
from config import MONGO_URL

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class DatabaseManager:
    def __init__(self):
        """Initialize MongoDB connection"""
        try:
            self.mongo_client = MongoClient(MONGO_URL)
            # Test connection
            self.mongo_client.admin.command('ping')
            self.db = self.mongo_client.bot_users
            self.groups_col = self.db.groups
            self.users_col = self.db.users
            logger.info("Successfully connected to MongoDB")
        except ConnectionFailure as e:
            logger.error(f"Failed to connect to MongoDB: {e}")
            raise
        except Exception as e:
            logger.error(f"Unexpected error connecting to MongoDB: {e}")
            raise

    def add_user(self, user_id: int, name: str) -> bool:
        """Add or update user in database"""
        try:
            result = self.users_col.update_one(
                {"_id": user_id}, 
                {"$set": {"name": name}}, 
                upsert=True
            )
            logger.info(f"User {user_id} ({name}) {'updated' if result.matched_count else 'added'}")
            return True
        except OperationFailure as e:
            logger.error(f"Failed to add/update user {user_id}: {e}")
            return False

    def add_group(self, group_id: int, name: str) -> bool:
        """Add or update group in database"""
        try:
            result = self.groups_col.update_one(
                {"_id": group_id}, 
                {"$set": {"name": name}}, 
                upsert=True
            )
            logger.info(f"Group {group_id} ({name}) {'updated' if result.matched_count else 'added'}")
            return True
        except OperationFailure as e:
            logger.error(f"Failed to add/update group {group_id}: {e}")
            return False

    def get_users_count(self) -> int:
        """Get total number of users"""
        try:
            return self.users_col.count_documents({})
        except OperationFailure as e:
            logger.error(f"Failed to count users: {e}")
            return 0

    def get_groups_count(self) -> int:
        """Get total number of groups"""
        try:
            return self.groups_col.count_documents({})
        except OperationFailure as e:
            logger.error(f"Failed to count groups: {e}")
            return 0

    def get_all_users(self) -> list:
        """Get all users for broadcasting"""
        try:
            return list(self.users_col.find({}, {"_id": 1}))
        except OperationFailure as e:
            logger.error(f"Failed to fetch users: {e}")
            return []

    def get_all_groups(self) -> list:
        """Get all groups for broadcasting"""
        try:
            return list(self.groups_col.find({}, {"_id": 1}))
        except OperationFailure as e:
            logger.error(f"Failed to fetch groups: {e}")
            return []

    def clear_all_data(self) -> bool:
        """Clear all data from database"""
        try:
            users_deleted = self.users_col.delete_many({}).deleted_count
            groups_deleted = self.groups_col.delete_many({}).deleted_count
            logger.info(f"Cleared {users_deleted} users and {groups_deleted} groups")
            return True
        except OperationFailure as e:
            logger.error(f"Failed to clear database: {e}")
            return False

    def close_connection(self):
        """Close MongoDB connection"""
        try:
            self.mongo_client.close()
            logger.info("MongoDB connection closed")
        except Exception as e:
            logger.error(f"Error closing MongoDB connection: {e}")

# Initialize database manager
db_manager = DatabaseManager()
